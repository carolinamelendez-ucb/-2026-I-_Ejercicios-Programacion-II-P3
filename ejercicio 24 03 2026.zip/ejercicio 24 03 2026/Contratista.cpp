#include "Contratista.h"

Contratista::Contratista(string nombre, float salario_base, string departamento, int dias_trabajados)
    : Empleado(nombre, salario_base, departamento) {
    this->dias_trabajados = dias_trabajados;
}

float Contratista::calcular_salario() {
    return salario_base * dias_trabajados;
}