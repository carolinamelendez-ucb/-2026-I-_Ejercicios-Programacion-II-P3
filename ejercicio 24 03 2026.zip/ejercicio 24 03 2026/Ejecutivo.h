#pragma once
#include <iostream>
#include <string>
#include "Empleado.h"
using namespace std;

class Ejecutivo : public Empleado {
private:
    float comision;

public:
    Ejecutivo(string nombre, float salario_base, string departamento, float comision);

    float calcular_salario();
};
