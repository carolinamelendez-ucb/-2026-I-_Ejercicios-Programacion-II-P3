#pragma once
#include <iostream>
#include <string>
#include "Empleado.h"
using namespace std;

class EmpleadoPlanta : public Empleado {
public:
    EmpleadoPlanta(string nombre, float salario_base, string departamento);

    float calcular_salario();
};

