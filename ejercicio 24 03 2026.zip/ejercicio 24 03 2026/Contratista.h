#pragma once
#include <iostream>
#include <string>
#include "Empleado.h"
using namespace std;

class Contratista : public Empleado {
private:
    int dias_trabajados;

public:
    Contratista(string nombre, float salario_base, string departamento, int dias_trabajados);

    float calcular_salario();
};

