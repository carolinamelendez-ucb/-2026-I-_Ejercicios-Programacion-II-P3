#include "Empleado.h"

Empleado::Empleado(string nombre, float salario_base, string departamento) {
    this->nombre = nombre;
    this->salario_base = salario_base;
    this->departamento = departamento;
}

float Empleado::calcular_salario() {
    return salario_base;
}