#pragma once
#include <iostream>
#include <string>
using namespace std;

class Empleado {
protected:
    string nombre;
    float salario_base;
    string departamento;

public:
    Empleado(string nombre, float salario_base, string departamento);

    float calcular_salario();
};
