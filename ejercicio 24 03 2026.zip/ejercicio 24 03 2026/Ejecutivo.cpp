#include "Ejecutivo.h"

Ejecutivo::Ejecutivo(string nombre, float salario_base, string departamento, float comision)
    : Empleado(nombre, salario_base, departamento) {
    this->comision = comision;
}

float Ejecutivo::calcular_salario() {
    return salario_base + comision;
}