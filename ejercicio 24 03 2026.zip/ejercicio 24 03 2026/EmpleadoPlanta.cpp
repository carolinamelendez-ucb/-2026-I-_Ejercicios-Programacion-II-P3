#include "EmpleadoPlanta.h"

EmpleadoPlanta::EmpleadoPlanta(string nombre, float salario_base, string departamento)
    : Empleado(nombre, salario_base, departamento) {
}

float EmpleadoPlanta::calcular_salario() {
    return salario_base + 1000;
}