// Ejercicio 24 03 2026
#include <iostream>
#include "EmpleadoPlanta.h"
#include "Contratista.h"
#include "Ejecutivo.h"
using namespace std;

int main() {
    EmpleadoPlanta empPlanta("Marco Polo", 2000, "Produccion");
    Contratista empContratista("Maria Fernandez", 100, "Mantenimiento", 20);
    Ejecutivo empEjecutivo("Carlos Arandia", 3000, "Ventas", 1500);

    cout << "Salario Empleado de Planta: $" << empPlanta.calcular_salario() << endl;
    cout << "Salario Contratista: $" << empContratista.calcular_salario() << endl;
    cout << "Salario Ejecutivo: $" << empEjecutivo.calcular_salario() << endl;

    return 0;
}