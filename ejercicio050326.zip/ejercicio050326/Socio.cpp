#include "Socio.h"

Socio::Socio() {
    this->ci = "";
    this->nombre = "";
    this->telefono = "";
}

Socio::Socio(string ci, string nombre, string telefono) {
    this->ci = ci;
    this->nombre = nombre;
    this->telefono = telefono;
}

string Socio::getCi() { 
    return ci; 
}

string Socio::getNombre() { 
    return nombre; 
}

string Socio::getTelefono() { 
    return telefono; 
}

void Socio::setCi(string ci) { 
    this->ci = ci; 
}

void Socio::setNombre(string nombre) { 
    this->nombre = nombre; 
}

void Socio::setTelefono(string telefono) { 
    this->telefono = telefono; 
}

void Socio::mostrar() {
    cout << "CI: " << ci << ", Nombre: " << nombre << ", Telefono: " << telefono;
}