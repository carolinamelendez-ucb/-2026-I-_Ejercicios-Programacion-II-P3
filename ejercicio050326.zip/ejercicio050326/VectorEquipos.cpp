#include "VectorEquipos.h"
#include <iostream>
using namespace std;

VectorEquipos::VectorEquipos() {
    capacidad = 5;
    cantidad = 0;
    equipos = new Equipo[capacidad];
}

VectorEquipos::~VectorEquipos() {
    delete[] equipos;
}

void VectorEquipos::expandir() {
    capacidad *= 2;
    Equipo* temp = new Equipo[capacidad];
    for (int i = 0; i < cantidad; i++) {
        temp[i] = equipos[i];
    }
    delete[] equipos;
    equipos = temp;
}

void VectorEquipos::agregarEquipo(Equipo e) {
    if (cantidad >= capacidad) {
        expandir();
    }
    equipos[cantidad] = e;
    cantidad++;
}

int VectorEquipos::getCantidad() {
    return cantidad;
}

Equipo VectorEquipos::getEquipo(int indice) {
    if (indice >= 0 && indice < cantidad) {
        return equipos[indice];
    }
    return Equipo();
}

void VectorEquipos::mostrarTodos() {
    if (cantidad == 0) {
        cout << "No hay equipos registrados." << endl;
        return;
    }

    cout << "\n=== Lista de equipos ===" << endl;
    for (int i = 0; i < cantidad; i++) {
        cout << "\nEquipo #" << i + 1 << endl;
        equipos[i].mostrar();
    }
}

void VectorEquipos::buscarEquiposDeSocio(Socio* socio) {
    if (socio == NULL) {
        cout << "Socio no valido." << endl;
        return;
    }

    bool encontrado = false;
    cout << "\n=== Equipos donde participa " << socio->getNombre() << " ===" << endl;

    for (int i = 0; i < cantidad; i++) {
        if (equipos[i].contieneSocio(socio)) {
            cout << "- " << equipos[i].getNombreEquipo() << " (Auto: " << equipos[i].getAuto() << ")" << endl;
            encontrado = true;
        }
    }

    if (!encontrado) {
        cout << "El socio no esta inscrito en ningun equipo." << endl;
    }
}