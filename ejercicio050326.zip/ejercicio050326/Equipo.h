#pragma once
#include <string>
#include "Socio.h"
using namespace std;

class Equipo {
private:
    string nombreEquipo;
    Socio* piloto;
    Socio* copiloto;
    string autoEquipo;

public:
    Equipo();
    Equipo(string nombre, Socio* p, Socio* cp, string autoE);

    string getNombreEquipo();
    Socio* getPiloto();
    Socio* getCopiloto();
    string getAuto();

    bool contieneSocio(Socio* socio);
    void mostrar();
};

