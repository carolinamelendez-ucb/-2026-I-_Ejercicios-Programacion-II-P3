#pragma once
#include "Socio.h"

class VectorSocios {
private:
    Socio* socios;
    int cantidad;
    int capacidad;

    void expandir();
    void ordenarAlfabeticamente();

public:
    VectorSocios();
    ~VectorSocios();

    void agregarSocio(Socio s);
    int getCantidad();
    Socio getSocio(int indice);
    Socio* buscarSocioPorNombre(string nombre);
    Socio* buscarSocioPorCI(string ci);
    void mostrarTodosOrdenados();
};


