#pragma once
#include <iostream>
#include <string>
using namespace std;

class Socio {
private:
    string ci;
    string nombre;
    string telefono;

public:
    Socio();
    Socio(string ci, string nombre, string telefono);

    string getCi();
    string getNombre();
    string getTelefono();

    void setCi(string ci);
    void setNombre(string nombre);
    void setTelefono(string telefono);

    void mostrar();
};
