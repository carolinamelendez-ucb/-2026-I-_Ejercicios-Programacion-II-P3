#pragma once
#include <string>
#include "Equipo.h"
#include "VectorEquipos.h"
using namespace std;

class Competencia {
private:
    string nombreCompetencia;
    int maxEquipos;
    Equipo** equiposInscritos;
    int cantidadInscritos;

public:
    Competencia();
    Competencia(string nombre, int max);
    ~Competencia();

    string getNombreCompetencia();
    int getMaxEquipos();
    int getCantidadInscritos();

    bool inscribirEquipo(Equipo* equipo, VectorEquipos& todosLosEquipos);
    void mostrarEquiposInscritos();
};

