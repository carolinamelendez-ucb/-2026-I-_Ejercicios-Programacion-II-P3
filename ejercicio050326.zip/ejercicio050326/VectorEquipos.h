#pragma once
#include "Equipo.h"

class VectorEquipos {
private:
    Equipo* equipos;
    int cantidad;
    int capacidad;

    void expandir();

public:
    VectorEquipos();
    ~VectorEquipos();

    void agregarEquipo(Equipo e);
    int getCantidad();
    Equipo getEquipo(int indice);
    void mostrarTodos();
    void buscarEquiposDeSocio(Socio* socio);
};

