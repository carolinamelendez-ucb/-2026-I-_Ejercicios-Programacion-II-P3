#include "VectorSocios.h"
#include <iostream>
#include <string>
using namespace std;

VectorSocios::VectorSocios() {
    capacidad = 5;
    cantidad = 0;
    socios = new Socio[capacidad];
}

VectorSocios::~VectorSocios() {
    delete[] socios;
}

void VectorSocios::expandir() {
    capacidad *= 2;
    Socio* temp = new Socio[capacidad];
    for (int i = 0; i < cantidad; i++) {
        temp[i] = socios[i];
    }
    delete[] socios;
    socios = temp;
}

void VectorSocios::agregarSocio(Socio s) {
    if (cantidad >= capacidad) {
        expandir();
    }
    socios[cantidad] = s;
    cantidad++;
}

int VectorSocios::getCantidad() {
    return cantidad;
}

Socio VectorSocios::getSocio(int indice) {
    if (indice >= 0 && indice < cantidad) {
        return socios[indice];
    }
    return Socio();
}

Socio* VectorSocios::buscarSocioPorNombre(string nombre) {
    for (int i = 0; i < cantidad; i++) {
        if (socios[i].getNombre() == nombre) {
            return &socios[i];
        }
    }
    return NULL;
}

Socio* VectorSocios::buscarSocioPorCI(string ci) {
    for (int i = 0; i < cantidad; i++) {
        if (socios[i].getCi() == ci) {
            return &socios[i];
        }
    }
    return NULL;
}

void VectorSocios::ordenarAlfabeticamente() {
    for (int i = 0; i < cantidad - 1; i++) {
        for (int j = 0; j < cantidad - i - 1; j++) {
            if (socios[j].getNombre() > socios[j + 1].getNombre()) {
                Socio temp = socios[j];
                socios[j] = socios[j + 1];
                socios[j + 1] = temp;
            }
        }
    }
}

void VectorSocios::mostrarTodosOrdenados() {
    if (cantidad == 0) {
        cout << "No hay socios registrados." << endl;
        return;
    }

    ordenarAlfabeticamente();

    cout << "\n=== Lista de socios (Orden alfabetico) ===" << endl;
    for (int i = 0; i < cantidad; i++) {
        cout << i + 1 << ". ";
        socios[i].mostrar();
        cout << endl;
    }
}