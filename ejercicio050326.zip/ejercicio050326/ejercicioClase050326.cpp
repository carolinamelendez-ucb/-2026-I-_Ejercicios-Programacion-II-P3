#include <iostream>
#include <string>
#include "Socio.h"
#include "VectorSocios.h"
#include "Equipo.h"
#include "VectorEquipos.h"
#include "Competencia.h"
using namespace std;

void mostrarMenu() {
    cout << "Asociacion automovilistica - Sistema de gestion" << endl;
    cout << "1. Registrar nuevo socio" << endl;
    cout << "2. Mostrar todos los socios (orden alfabetico)" << endl;
    cout << "3. Crear nuevo equipo" << endl;
    cout << "4. Mostrar todos los equipos" << endl;
    cout << "5. Crear nueva competencia" << endl;
    cout << "6. Inscribir equipo en competencia" << endl;
    cout << "7. Mostrar equipos inscritos en competencia" << endl;
    cout << "8. Buscar equipos de un socio" << endl;
    cout << "9. Salir" << endl;
    cout << "Seleccione una opcion: ";
}

int main() {
    VectorSocios listaSocios;
    VectorEquipos listaEquipos;
    Competencia* competenciaActual = NULL;
    int opcion;

    listaSocios.agregarSocio(Socio("1234567", "Juan Perez", "77712345"));
    listaSocios.agregarSocio(Socio("7654321", "Maria Lopez", "77754321"));
    listaSocios.agregarSocio(Socio("4567890", "Carlos Gomez", "77798765"));
    listaSocios.agregarSocio(Socio("8901234", "Ana Silva", "77745678"));
    listaSocios.agregarSocio(Socio("3456789", "Pedro Rodriguez", "77734567"));

    do {
        mostrarMenu();
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
        case 1: {
            string ci, nombre, telefono;
            cout << "Ingrese CI del socio: ";
            getline(cin, ci);
            cout << "Ingrese nombre del socio: ";
            getline(cin, nombre);
            cout << "Ingrese telefono del socio: ";
            getline(cin, telefono);

            listaSocios.agregarSocio(Socio(ci, nombre, telefono));
            cout << "Socio registrado exitosamente!" << endl;
            break;
        }

        case 2: {
            listaSocios.mostrarTodosOrdenados();
            break;
        }

        case 3: {
            string nombreEquipo, nombrePiloto, nombreCopiloto, autoEquipo;

            cout << "Ingrese el nombre del equipo: ";
            getline(cin, nombreEquipo);

            cout << "Ingrese el nombre del piloto: ";
            getline(cin, nombrePiloto);

            cout << "Ingrese el nombre del copiloto: ";
            getline(cin, nombreCopiloto);

            if (nombrePiloto == nombreCopiloto) {
                cout << "Error: El piloto y el copiloto no pueden tener el mismo nombre." << endl;
                break;
            }

            cout << "Ingrese el auto del equipo: ";
            getline(cin, autoEquipo);

            Socio* piloto = listaSocios.buscarSocioPorNombre(nombrePiloto);
            Socio* copiloto = listaSocios.buscarSocioPorNombre(nombreCopiloto);

            if (piloto == NULL) {
                cout << "Error: No se encontro al piloto con nombre '" << nombrePiloto << "'" << endl;
                break;
            }

            if (copiloto == NULL) {
                cout << "Error: No se encontro al copiloto con nombre '" << nombreCopiloto << "'" << endl;
                break;
            }

            Equipo nuevoEquipo(nombreEquipo, piloto, copiloto, autoEquipo);
            listaEquipos.agregarEquipo(nuevoEquipo);

            cout << "Equipo registrado exitosamente!" << endl;
            break;
        }

        case 4: {
            listaEquipos.mostrarTodos();
            break;
        }

        case 5: {
            string nombreCompetencia;
            int maxEquipos;

            cout << "Ingrese el nombre de la competencia: ";
            getline(cin, nombreCompetencia);
            cout << "Ingrese el maximo de equipos permitidos: ";
            cin >> maxEquipos;
            cin.ignore();

            if (competenciaActual != NULL) {
                delete competenciaActual;
            }

            competenciaActual = new Competencia(nombreCompetencia, maxEquipos);
            cout << "Competencia creada exitosamente!" << endl;
            break;
        }

        case 6: {
            if (competenciaActual == NULL) {
                cout << "Primero debe crear una competencia." << endl;
                break;
            }

            string nombreEquipo;
            cout << "Ingrese el nombre del equipo a inscribir: ";
            getline(cin, nombreEquipo);

            Equipo* equipoEncontrado = NULL;
            for (int i = 0; i < listaEquipos.getCantidad(); i++) {
                Equipo temp = listaEquipos.getEquipo(i);
                if (temp.getNombreEquipo() == nombreEquipo) {
                    equipoEncontrado = new Equipo(temp.getNombreEquipo(),
                        temp.getPiloto(),
                        temp.getCopiloto(),
                        temp.getAuto());
                    break;
                }
            }

            if (equipoEncontrado == NULL) {
                cout << "Error: No se encontro el equipo." << endl;
                break;
            }

            competenciaActual->inscribirEquipo(equipoEncontrado, listaEquipos);
            break;
        }
          
        case 7: {
            if (competenciaActual == NULL) {
                cout << "No hay competencia creada." << endl;
            }
            else {
                competenciaActual->mostrarEquiposInscritos();
            }
            break;
        }

        case 8: {
            string nombreSocio;
            cout << "Ingrese el nombre del socio a buscar: ";
            getline(cin, nombreSocio);

            Socio* socio = listaSocios.buscarSocioPorNombre(nombreSocio);
            if (socio == NULL) {
                cout << "No se encontro el socio." << endl;
            }
            else {
                listaEquipos.buscarEquiposDeSocio(socio);
            }
            break;
        }

        case 9: {
            cout << "Saliendo del sistema..." << endl;
            break;
        }

        default:
            cout << "Opcion no valida. Intente nuevamente." << endl;
        }
    } while (opcion != 9);

    if (competenciaActual != NULL) {
        delete competenciaActual;
    }

    return 0;
}

