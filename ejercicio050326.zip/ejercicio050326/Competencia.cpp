#include "Competencia.h"
#include <iostream>
using namespace std;

Competencia::Competencia() {
    nombreCompetencia = "";
    maxEquipos = 0;
    cantidadInscritos = 0;
    equiposInscritos = new Equipo * [10];
}

Competencia::Competencia(string nombre, int max) {
    nombreCompetencia = nombre;
    maxEquipos = max;
    cantidadInscritos = 0;
    equiposInscritos = new Equipo * [max];
}

Competencia::~Competencia() {
    delete[] equiposInscritos;
}

string Competencia::getNombreCompetencia() {
    return nombreCompetencia;
}

int Competencia::getMaxEquipos() {
    return maxEquipos;
}

int Competencia::getCantidadInscritos() {
    return cantidadInscritos;
}

bool Competencia::inscribirEquipo(Equipo* equipo, VectorEquipos& todosLosEquipos) {
    if (cantidadInscritos >= maxEquipos) {
        cout << "Error: La competencia ya tiene el maximo de equipos permitidos." << endl;
        return false;
    }

    bool equipoExiste = false;
    for (int i = 0; i < todosLosEquipos.getCantidad(); i++) {
        Equipo temp = todosLosEquipos.getEquipo(i);
        if (temp.getNombreEquipo() == equipo->getNombreEquipo()) {
            equipoExiste = true;
            break;
        }
    }

    if (!equipoExiste) {
        cout << "Error: El equipo no esta registrado en el sistema." << endl;
        return false;
    }

    Socio* piloto = equipo->getPiloto();
    Socio* copiloto = equipo->getCopiloto();

    for (int i = 0; i < cantidadInscritos; i++) {
        if (equiposInscritos[i]->contieneSocio(piloto) ||
            equiposInscritos[i]->contieneSocio(copiloto)) {
            cout << "Error: Un socio ya esta inscrito en otro equipo para esta competencia." << endl;
            return false;
        }
    }

    equiposInscritos[cantidadInscritos] = equipo;
    cantidadInscritos++;
    cout << "Equipo inscrito exitosamente en la competencia." << endl;
    return true;
}

void Competencia::mostrarEquiposInscritos() {
    if (cantidadInscritos == 0) {
        cout << "No hay equipos inscritos en esta competencia." << endl;
        return;
    }

    cout << "\n=== Equipos inscritos en " << nombreCompetencia << " ===" << endl;
    for (int i = 0; i < cantidadInscritos; i++) {
        cout << i + 1 << ". " << equiposInscritos[i]->getNombreEquipo() << endl;
    }
}
