#include "Equipo.h"
#include <iostream>
using namespace std;

Equipo::Equipo() {
    nombreEquipo = "";
    piloto = NULL;
    copiloto = NULL;
    autoEquipo = "";
}

Equipo::Equipo(string nombre, Socio* p, Socio* cp, string autoE) {
    nombreEquipo = nombre;
    piloto = p;
    copiloto = cp;
    autoEquipo = autoE;
}

string Equipo::getNombreEquipo() { 
    return nombreEquipo; 
}

Socio* Equipo::getPiloto() { 
    return piloto; 
}

Socio* Equipo::getCopiloto() { 
    return copiloto; 
}

string Equipo::getAuto() { 
    return autoEquipo; 
}

bool Equipo::contieneSocio(Socio* socio) {
    return (piloto == socio || copiloto == socio);
}

void Equipo::mostrar() {
    cout << "Equipo: " << nombreEquipo << ", Auto: " << autoEquipo << endl;
    cout << "  Piloto: ";
    if (piloto != NULL) piloto->mostrar();
    else cout << "No asignado";
    cout << endl;

    cout << "  Copiloto: ";
    if (copiloto != NULL) copiloto->mostrar();
    else cout << "No asignado";
    cout << endl;
}