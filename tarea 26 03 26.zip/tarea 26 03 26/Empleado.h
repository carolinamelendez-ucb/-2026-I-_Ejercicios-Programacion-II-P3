#pragma once
#include <string>
using namespace std;

class Empleado {
public:
    string nombre;
    string ci;
    int funcionesAtendidas;
    string estado;

    Empleado();
    Empleado(string nombre, string ci);
    void incrementarFunciones();
    void liberar();
};
