#pragma once
#include <string>
using namespace std;

class Espectador {
public:
    string nombre;
    string telefono;

    Espectador();
    Espectador(string nombre, string telefono);
};