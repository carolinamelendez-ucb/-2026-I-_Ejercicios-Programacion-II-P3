#pragma once
#include "Empleado.h"

class VectorEmpleado {
private:
    Empleado* empleados;
    int cantidad;
    int capacidad;

public:
    VectorEmpleado();
    ~VectorEmpleado();
    void agregar(Empleado e);
    bool existeCi(string ci);
    void ordenarPorFunciones();
    Empleado* buscarLibreMenosFunciones();
    void mostrar();
    int getCantidad();
    Empleado getEmpleado(int index);
};
