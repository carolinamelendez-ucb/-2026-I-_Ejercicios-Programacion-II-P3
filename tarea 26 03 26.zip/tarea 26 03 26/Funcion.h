#pragma once
#include <string>
#include "VectorEspectador.h"
#include "Empleado.h"
using namespace std;

class Funcion {
public:
    string nombrePelicula;
    string codigo;
    int maxEspectadores;
    VectorEspectador espectadores;
    Empleado* empleadoAsignado;

    Funcion();
    Funcion(string nombrePelicula, string codigo, int maxEspectadores);
    void agregarEspectador(Espectador e);
    bool hayEspacio();
};

