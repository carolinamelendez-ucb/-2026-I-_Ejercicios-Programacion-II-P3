#pragma once
#include "VectorEmpleado.h"
#include "VectorFuncion.h"

class SistemaCine {
private:
    VectorEmpleado empleados;
    VectorFuncion funciones;

public:
    SistemaCine();
    void registrarEmpleado(string nombre, string ci);
    void mostrarEmpleadosOrdenados();
    void registrarFuncion(string nombrePelicula, string codigo, int maxEspectadores);
    void finalizarFuncion(string codigo);
    void agregarEspectadorAFuncion(string codigo, string nombre, string telefono);
};
