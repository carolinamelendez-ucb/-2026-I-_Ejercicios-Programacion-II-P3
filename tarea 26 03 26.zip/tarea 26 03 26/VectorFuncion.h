#pragma once
#include "Funcion.h"

class VectorFuncion {
private:
    Funcion* funciones;
    int cantidad;
    int capacidad;

public:
    VectorFuncion();
    ~VectorFuncion();
    void agregar(Funcion f);
    bool existeCodigo(string codigo);
    void mostrar();
    int getCantidad();
    Funcion getFuncion(int index);
    void finalizarFuncion(int index);
};
