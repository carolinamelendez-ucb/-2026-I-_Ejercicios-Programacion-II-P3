#pragma once
#include "Espectador.h"

class VectorEspectador {
private:
    Espectador* espectadores;
    int cantidad;
    int capacidad;

public:
    VectorEspectador();
    ~VectorEspectador();
    void agregar(Espectador e);
    void mostrar();
    int getCantidad();
    Espectador getEspectador(int index);
};
