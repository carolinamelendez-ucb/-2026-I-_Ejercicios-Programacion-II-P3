#include <iostream>
#include <string>
#include "SistemaCine.h"
using namespace std;

Empleado::Empleado() {
    nombre = "";
    ci = "";
    funcionesAtendidas = 0;
    estado = "libre";
}

Empleado::Empleado(string nombre, string ci) {
    this->nombre = nombre;
    this->ci = ci;
    funcionesAtendidas = 0;
    estado = "libre";
}

void Empleado::incrementarFunciones() {
    funcionesAtendidas++;
}

void Empleado::liberar() {
    estado = "libre";
}

VectorEmpleado::VectorEmpleado() {
    capacidad = 10;
    cantidad = 0;
    empleados = new Empleado[capacidad];
}

VectorEmpleado::~VectorEmpleado() {
    delete[] empleados;
}

void VectorEmpleado::agregar(Empleado e) {
    if (cantidad == capacidad) {
        capacidad *= 2;
        Empleado* nuevo = new Empleado[capacidad];
        for (int i = 0; i < cantidad; i++) {
            nuevo[i] = empleados[i];
        }
        delete[] empleados;
        empleados = nuevo;
    }
    empleados[cantidad] = e;
    cantidad++;
}

bool VectorEmpleado::existeCi(string ci) {
    for (int i = 0; i < cantidad; i++) {
        if (empleados[i].ci == ci) {
            return true;
        }
    }
    return false;
}

void VectorEmpleado::ordenarPorFunciones() {
    for (int i = 0; i < cantidad - 1; i++) {
        for (int j = i + 1; j < cantidad; j++) {
            if (empleados[i].funcionesAtendidas > empleados[j].funcionesAtendidas) {
                Empleado temp = empleados[i];
                empleados[i] = empleados[j];
                empleados[j] = temp;
            }
        }
    }
}

Empleado* VectorEmpleado::buscarLibreMenosFunciones() {
    Empleado* seleccionado = 0;
    for (int i = 0; i < cantidad; i++) {
        if (empleados[i].estado == "libre") {
            if (seleccionado == 0 || empleados[i].funcionesAtendidas < seleccionado->funcionesAtendidas) {
                seleccionado = &empleados[i];
            }
        }
    }
    return seleccionado;
}

void VectorEmpleado::mostrar() {
    for (int i = 0; i < cantidad; i++) {
        cout << "Nombre: " << empleados[i].nombre << ", CI: " << empleados[i].ci
            << ", Funciones: " << empleados[i].funcionesAtendidas << ", Estado: " << empleados[i].estado << endl;
    }
}

int VectorEmpleado::getCantidad() {
    return cantidad;
}

Empleado VectorEmpleado::getEmpleado(int index) {
    return empleados[index];
}

Espectador::Espectador() {
    nombre = "";
    telefono = "";
}

Espectador::Espectador(string nombre, string telefono) {
    this->nombre = nombre;
    this->telefono = telefono;
}

VectorEspectador::VectorEspectador() {
    capacidad = 10;
    cantidad = 0;
    espectadores = new Espectador[capacidad];
}

VectorEspectador::~VectorEspectador() {
    delete[] espectadores;
}

void VectorEspectador::agregar(Espectador e) {
    if (cantidad == capacidad) {
        capacidad *= 2;
        Espectador* nuevo = new Espectador[capacidad];
        for (int i = 0; i < cantidad; i++) {
            nuevo[i] = espectadores[i];
        }
        delete[] espectadores;
        espectadores = nuevo;
    }
    espectadores[cantidad] = e;
    cantidad++;
}

void VectorEspectador::mostrar() {
    for (int i = 0; i < cantidad; i++) {
        cout << "Nombre: " << espectadores[i].nombre << ", Telefono: " << espectadores[i].telefono << endl;
    }
}

int VectorEspectador::getCantidad() {
    return cantidad;
}

Espectador VectorEspectador::getEspectador(int index) {
    return espectadores[index];
}

Funcion::Funcion() {
    nombrePelicula = "";
    codigo = "";
    maxEspectadores = 0;
    empleadoAsignado = 0;
}

Funcion::Funcion(string nombrePelicula, string codigo, int maxEspectadores) {
    this->nombrePelicula = nombrePelicula;
    this->codigo = codigo;
    this->maxEspectadores = maxEspectadores;
    empleadoAsignado = 0;
}

void Funcion::agregarEspectador(Espectador e) {
    if (espectadores.getCantidad() < maxEspectadores) {
        espectadores.agregar(e);
    }
}

bool Funcion::hayEspacio() {
    return espectadores.getCantidad() < maxEspectadores;
}

VectorFuncion::VectorFuncion() {
    capacidad = 10;
    cantidad = 0;
    funciones = new Funcion[capacidad];
}

VectorFuncion::~VectorFuncion() {
    delete[] funciones;
}

void VectorFuncion::agregar(Funcion f) {
    if (cantidad == capacidad) {
        capacidad *= 2;
        Funcion* nuevo = new Funcion[capacidad];
        for (int i = 0; i < cantidad; i++) {
            nuevo[i] = funciones[i];
        }
        delete[] funciones;
        funciones = nuevo;
    }
    funciones[cantidad] = f;
    cantidad++;
}

bool VectorFuncion::existeCodigo(string codigo) {
    for (int i = 0; i < cantidad; i++) {
        if (funciones[i].codigo == codigo) {
            return true;
        }
    }
    return false;
}

void VectorFuncion::mostrar() {
    for (int i = 0; i < cantidad; i++) {
        cout << "Pelicula: " << funciones[i].nombrePelicula << ", Codigo: " << funciones[i].codigo
            << ", Max Espectadores: " << funciones[i].maxEspectadores << endl;
        if (funciones[i].empleadoAsignado != nullptr) {
            cout << "Empleado asignado: " << funciones[i].empleadoAsignado->nombre << endl;
        }
        cout << "Espectadores: " << endl;
        funciones[i].espectadores.mostrar();
        cout << "-------------------" << endl;
    }
}

int VectorFuncion::getCantidad() {
    return cantidad;
}

Funcion VectorFuncion::getFuncion(int index) {
    return funciones[index];
}

void VectorFuncion::finalizarFuncion(int index) {
    if (funciones[index].empleadoAsignado != nullptr) {
        funciones[index].empleadoAsignado->incrementarFunciones();
        funciones[index].empleadoAsignado->liberar();
        funciones[index].empleadoAsignado = nullptr;
    }
}

SistemaCine::SistemaCine() {}

void SistemaCine::registrarEmpleado(string nombre, string ci) {
    if (!empleados.existeCi(ci)) {
        Empleado e(nombre, ci);
        empleados.agregar(e);
        cout << "Empleado registrado exitosamente." << endl;
    }
    else {
        cout << "Error: CI duplicado." << endl;
    }
}

void SistemaCine::mostrarEmpleadosOrdenados() {
    empleados.ordenarPorFunciones();
    empleados.mostrar();
}

void SistemaCine::registrarFuncion(string nombrePelicula, string codigo, int maxEspectadores) {
    if (funciones.existeCodigo(codigo)) {
        cout << "Error: Codigo de funcion duplicado." << endl;
        return;
    }

    Empleado* empleadoLibre = empleados.buscarLibreMenosFunciones();
    if (empleadoLibre == 0) {
        cout << "Error: No hay empleados libres." << endl;
        return;
    }

    Funcion f(nombrePelicula, codigo, maxEspectadores);
    f.empleadoAsignado = empleadoLibre;
    empleadoLibre->estado = "ocupado";
    funciones.agregar(f);
    cout << "Funcion registrada exitosamente. Empleado asignado: " << empleadoLibre->nombre << endl;
}

void SistemaCine::finalizarFuncion(string codigo) {
    for (int i = 0; i < funciones.getCantidad(); i++) {
        if (funciones.getFuncion(i).codigo == codigo) {
            funciones.finalizarFuncion(i);
            cout << "Funcion finalizada. Empleado liberado." << endl;
            return;
        }
    }
    cout << "Error: Funcion no encontrada." << endl;
}

void SistemaCine::agregarEspectadorAFuncion(string codigo, string nombre, string telefono) {
    for (int i = 0; i < funciones.getCantidad(); i++) {
        if (funciones.getFuncion(i).codigo == codigo) {
            if (funciones.getFuncion(i).hayEspacio()) {
                Espectador e(nombre, telefono);
                funciones.getFuncion(i).agregarEspectador(e);
                cout << "Espectador agregado a la funcion." << endl;
            }
            else {
                cout << "Error: No hay espacio en la funcion." << endl;
            }
            return;
        }
    }
    cout << "Error: Funcion no encontrada." << endl;
}

int main() {
    SistemaCine sistema;

    cout << "=== REGISTRO DE EMPLEADOS ===" << endl;
    sistema.registrarEmpleado("Juan Perez", "123456");
    sistema.registrarEmpleado("Maria Lopez", "789012");
    sistema.registrarEmpleado("Carlos Ruiz", "345678");
    sistema.registrarEmpleado("Ana Garcia", "123456");

    cout << "\n=== EMPLEADOS REGISTRADOS ===" << endl;
    sistema.mostrarEmpleadosOrdenados();

    cout << "\n=== REGISTRO DE FUNCIONES ===" << endl;
    sistema.registrarFuncion("Avatar", "F001", 100);
    sistema.registrarFuncion("Titanic", "F002", 80);
    sistema.registrarFuncion("Inception", "F003", 120);
    sistema.registrarFuncion("Avatar 2", "F001", 150);

    cout << "\n=== AGREGAR ESPECTADORES ===" << endl;
    sistema.agregarEspectadorAFuncion("F001", "Pedro Ramirez", "77712345");
    sistema.agregarEspectadorAFuncion("F001", "Laura Fernandez", "77754321");

    cout << "\n=== FINALIZAR FUNCION ===" << endl;
    sistema.finalizarFuncion("F001");

    cout << "\n=== EMPLEADOS DESPUES DE FINALIZAR FUNCION ===" << endl;
    sistema.mostrarEmpleadosOrdenados();

    cout << "\n=== REGISTRAR NUEVA FUNCION ===" << endl;
    sistema.registrarFuncion("Interstellar", "F004", 90);

    cout << "\n=== EMPLEADOS FINAL ===" << endl;
    sistema.mostrarEmpleadosOrdenados();

    return 0;
}