#pragma once
#include <iostream>
#include <string>
#include "Organizador.h"
#include "Invitado.h"
using namespace std;

class Evento {
private:
    int id;
    string nombre;
    int maxInvitados;
    int numInvitados;
    Organizador* organizador;
    Invitado** invitados;
    bool activo;

public:
    Evento();
    Evento(int id, string nombre, int maxInvitados);
    ~Evento();

    int getId();
    string getNombre();
    int getMaxInvitados();
    int getNumInvitados();
    Organizador* getOrganizador();
    bool getActivo();

    void setOrganizador(Organizador* org);
    void setActivo(bool estado);

    bool agregarInvitado(string nombre, string telefono);
    void finalizarEvento();
    void mostrarInfo();
    void mostrarInvitados();
};

