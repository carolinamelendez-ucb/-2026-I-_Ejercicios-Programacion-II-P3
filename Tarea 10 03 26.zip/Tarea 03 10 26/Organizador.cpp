#include "Organizador.h"

Organizador::Organizador() {
    this->id = 0;
    this->nombre = "";
    this->rank = 0;
    this->disponible = true;
}

Organizador::Organizador(string nombre, int id) {
    this->nombre = nombre;
    this->id = id;
    this->rank = 0;
    this->disponible = true;
}

int Organizador::getId() {
    return id;
}

string Organizador::getNombre() {
    return nombre;
}

int Organizador::getRank() {
    return rank;
}

bool Organizador::getDisponible() {
    return disponible;
}

void Organizador::setDisponible(bool disp) {
    this->disponible = disp;
}

void Organizador::incrementarRank() {
    this->rank++;
}

void Organizador::mostrarInfo() {
    cout << "ID: " << id << " | Nombre: " << nombre
        << " | Rank: " << rank << " | Disponible: "
        << (disponible ? "Si" : "No") << endl;
}