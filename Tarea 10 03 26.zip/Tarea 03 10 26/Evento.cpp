#include "Evento.h"

Evento::Evento() {
    this->id = 0;
    this->nombre = "";
    this->maxInvitados = 0;
    this->numInvitados = 0;
    this->organizador = NULL;
    this->invitados = new Invitado * [100];
    this->activo = true;
}

Evento::Evento(int id, string nombre, int maxInvitados) {
    this->id = id;
    this->nombre = nombre;
    this->maxInvitados = maxInvitados;
    this->numInvitados = 0;
    this->organizador = NULL;
    this->invitados = new Invitado * [100];
    this->activo = true;
}

Evento::~Evento() {
    for (int i = 0; i < numInvitados; i++) {
        delete invitados[i];
    }
    delete[] invitados;
}

int Evento::getId() {
    return id;
}

string Evento::getNombre() {
    return nombre;
}

int Evento::getMaxInvitados() {
    return maxInvitados;
}

int Evento::getNumInvitados() {
    return numInvitados;
}

Organizador* Evento::getOrganizador() {
    return organizador;
}

bool Evento::getActivo() {
    return activo;
}

void Evento::setOrganizador(Organizador* org) {
    this->organizador = org;
}

void Evento::setActivo(bool estado) {
    this->activo = estado;
}

bool Evento::agregarInvitado(string nombre, string telefono) {
    if (numInvitados >= maxInvitados) {
        cout << "No se pueden agregar mas invitados. Cupo maximo alcanzado." << endl;
        return false;
    }

    invitados[numInvitados] = new Invitado(nombre, telefono);
    numInvitados++;
    return true;
}

void Evento::finalizarEvento() {
    if (organizador != NULL) {
        organizador->incrementarRank();
        organizador->setDisponible(true);
    }
    this->activo = false;
}

void Evento::mostrarInfo() {
    cout << "ID Evento: " << id << " | Nombre: " << nombre
        << " | Max Invitados: " << maxInvitados
        << " | Invitados Actuales: " << numInvitados << endl;

    if (organizador != NULL) {
        cout << "Organizador: " << organizador->getNombre()
            << " (ID: " << organizador->getId() << ")" << endl;
    }
    else {
        cout << "Organizador: No asignado" << endl;
    }

    cout << "Estado: " << (activo ? "Activo" : "Finalizado") << endl;
}

void Evento::mostrarInvitados() {
    cout << "=== Lista de Invitados del Evento " << nombre << " ===" << endl;
    if (numInvitados == 0) {
        cout << "No hay invitados registrados." << endl;
    }
    else {
        for (int i = 0; i < numInvitados; i++) {
            cout << i + 1 << ". ";
            invitados[i]->mostrarInfo();
        }
    }
}