#include "Invitado.h"

Invitado::Invitado() {
    this->nombre = "";
    this->telefono = "";
}

Invitado::Invitado(string nombre, string telefono) {
    this->nombre = nombre;
    this->telefono = telefono;
}

string Invitado::getNombre() {
    return nombre;
}

string Invitado::getTelefono() {
    return telefono;
}

void Invitado::mostrarInfo() {
    cout << "Nombre: " << nombre << " | Telefono: " << telefono << endl;
}