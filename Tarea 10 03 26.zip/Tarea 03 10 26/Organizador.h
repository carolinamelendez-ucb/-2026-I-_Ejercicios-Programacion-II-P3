#pragma once
#include <iostream>
#include <string>
using namespace std;

class Organizador {
private:
    int id;
    string nombre;
    int rank;
    bool disponible;

public:
    Organizador();
    Organizador(string nombre, int id);

    int getId();
    string getNombre();
    int getRank();
    bool getDisponible();

    void setDisponible(bool disp);
    void incrementarRank();

    void mostrarInfo();
};

