// Tarea 03 10 26
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "Organizador.h"
#include "Evento.h"
#include "Invitado.h"
using namespace std;

int generarId();
void registrarOrganizador(Organizador**& organizadores, int& numOrganizadores);
void mostrarOrganizadores(Organizador** organizadores, int numOrganizadores);
void ordenarOrganizadoresPorRank(Organizador** organizadores, int numOrganizadores);
void mostrarOrganizadoresDisponibles(Organizador** organizadores, int numOrganizadores);
Organizador* buscarOrganizadorDisponible(Organizador** organizadores, int numOrganizadores);
void registrarEvento(Evento**& eventos, int& numEventos, Organizador** organizadores, int numOrganizadores);
void mostrarEventos(Evento** eventos, int numEventos);
void mostrarEventosActivos(Evento** eventos, int numEventos);
void registrarInvitadoEnEvento(Evento** eventos, int numEventos);
void finalizarEvento(Evento** eventos, int numEventos);
Evento* buscarEventoPorId(Evento** eventos, int numEventos, int id);

int main() {
    srand(time(NULL));

    Organizador** organizadores = new Organizador * [100];
    Evento** eventos = new Evento * [100];
    int numOrganizadores = 0;
    int numEventos = 0;

    int opcion;

    do {
        cout << "\n=== Sistema de Gestion de Eventos ===" << endl;
        cout << "1. Registrar Organizador" << endl;
        cout << "2. Mostrar Organizadores (ordenados por rank)" << endl;
        cout << "3. Mostrar Organizadores Disponibles" << endl;
        cout << "4. Registrar Evento" << endl;
        cout << "5. Mostrar Eventos" << endl;
        cout << "6. Registrar Invitado en Evento" << endl;
        cout << "7. Finalizar Evento" << endl;
        cout << "8. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
        case 1:
            registrarOrganizador(organizadores, numOrganizadores);
            break;
        case 2:
            mostrarOrganizadores(organizadores, numOrganizadores);
            break;
        case 3:
            mostrarOrganizadoresDisponibles(organizadores, numOrganizadores);
            break;
        case 4:
            registrarEvento(eventos, numEventos, organizadores, numOrganizadores);
            break;
        case 5:
            mostrarEventos(eventos, numEventos);
            break;
        case 6:
            registrarInvitadoEnEvento(eventos, numEventos);
            break;
        case 7:
            finalizarEvento(eventos, numEventos);
            break;
        case 8:
            cout << "Saliendo del sistema..." << endl;
            break;
        default:
            cout << "Opcion no valida" << endl;
        }
    } while (opcion != 8);

    for (int i = 0; i < numOrganizadores; i++) {
        delete organizadores[i];
    }
    delete[] organizadores;

    for (int i = 0; i < numEventos; i++) {
        delete eventos[i];
    }
    delete[] eventos;

    return 0;
}

int generarId() {
    return rand() % 9000 + 1000;
}

void registrarOrganizador(Organizador**& organizadores, int& numOrganizadores) {
    string nombre;
    cout << "Ingrese nombre del organizador: ";
    getline(cin, nombre);

    int id = generarId();
    organizadores[numOrganizadores] = new Organizador(nombre, id);
    numOrganizadores++;

    cout << "Organizador registrado con exito. ID: " << id << endl;
}

void ordenarOrganizadoresPorRank(Organizador** organizadores, int numOrganizadores) {
    for (int i = 0; i < numOrganizadores - 1; i++) {
        for (int j = 0; j < numOrganizadores - i - 1; j++) {
            if (organizadores[j]->getRank() < organizadores[j + 1]->getRank()) {
                Organizador* temp = organizadores[j];
                organizadores[j] = organizadores[j + 1];
                organizadores[j + 1] = temp;
            }
        }
    }
}

void mostrarOrganizadores(Organizador** organizadores, int numOrganizadores) {
    if (numOrganizadores == 0) {
        cout << "No hay organizadores registrados." << endl;
        return;
    }

    Organizador** temp = new Organizador * [numOrganizadores];
    for (int i = 0; i < numOrganizadores; i++) {
        temp[i] = organizadores[i];
    }

    ordenarOrganizadoresPorRank(temp, numOrganizadores);

    cout << "\n=== Organizadores Ordenados Por Rank ===" << endl;
    for (int i = 0; i < numOrganizadores; i++) {
        temp[i]->mostrarInfo();
    }

    delete[] temp;
}

void mostrarOrganizadoresDisponibles(Organizador** organizadores, int numOrganizadores) {
    if (numOrganizadores == 0) {
        cout << "No hay organizadores registrados." << endl;
        return;
    }

    cout << "\n=== Organizadores Disponibles ===" << endl;
    bool hayDisponibles = false;

    for (int i = 0; i < numOrganizadores; i++) {
        if (organizadores[i]->getDisponible()) {
            organizadores[i]->mostrarInfo();
            hayDisponibles = true;
        }
    }

    if (!hayDisponibles) {
        cout << "No hay organizadores disponibles en este momento." << endl;
    }
}

Organizador* buscarOrganizadorDisponible(Organizador** organizadores, int numOrganizadores) {
    Organizador* mejorOrganizador = NULL;
    int maxRank = -1;

    for (int i = 0; i < numOrganizadores; i++) {
        if (organizadores[i]->getDisponible() && organizadores[i]->getRank() > maxRank) {
            maxRank = organizadores[i]->getRank();
            mejorOrganizador = organizadores[i];
        }
    }

    return mejorOrganizador;
}

void registrarEvento(Evento**& eventos, int& numEventos, Organizador** organizadores, int numOrganizadores) {
    Organizador* orgAsignado = buscarOrganizadorDisponible(organizadores, numOrganizadores);

    if (orgAsignado == NULL) {
        cout << "No hay organizadores disponibles. No se puede registrar el evento." << endl;
        return;
    }

    string nombre;
    int maxInvitados;

    cout << "Ingrese nombre del evento: ";
    getline(cin, nombre);
    cout << "Ingrese maximo de invitados: ";
    cin >> maxInvitados;
    cin.ignore();

    int id = generarId();
    eventos[numEventos] = new Evento(id, nombre, maxInvitados);
    eventos[numEventos]->setOrganizador(orgAsignado);
    orgAsignado->setDisponible(false);

    numEventos++;

    cout << "Evento registrado con exito. ID: " << id << endl;
    cout << "Organizador asignado: " << orgAsignado->getNombre() << endl;
}

void mostrarEventos(Evento** eventos, int numEventos) {
    if (numEventos == 0) {
        cout << "No hay eventos registrados." << endl;
        return;
    }

    cout << "\n=== LISTA DE EVENTOS ===" << endl;
    for (int i = 0; i < numEventos; i++) {
        eventos[i]->mostrarInfo();
        cout << "------------------------" << endl;
    }
}

void mostrarEventosActivos(Evento** eventos, int numEventos) {
    if (numEventos == 0) {
        cout << "No hay eventos registrados." << endl;
        return;
    }

    cout << "\n=== Eventos Activos ===" << endl;
    bool hayActivos = false;

    for (int i = 0; i < numEventos; i++) {
        if (eventos[i]->getActivo()) {
            eventos[i]->mostrarInfo();
            cout << "------------------------" << endl;
            hayActivos = true;
        }
    }

    if (!hayActivos) {
        cout << "No hay eventos activos en este momento." << endl;
    }
}

Evento* buscarEventoPorId(Evento** eventos, int numEventos, int id) {
    for (int i = 0; i < numEventos; i++) {
        if (eventos[i]->getId() == id && eventos[i]->getActivo()) {
            return eventos[i];
        }
    }
    return NULL;
}

void registrarInvitadoEnEvento(Evento** eventos, int numEventos) {
    if (numEventos == 0) {
        cout << "No hay eventos registrados." << endl;
        return;
    }

    mostrarEventosActivos(eventos, numEventos);

    int idEvento;
    cout << "Ingrese ID del evento: ";
    cin >> idEvento;
    cin.ignore();

    Evento* evento = buscarEventoPorId(eventos, numEventos, idEvento);

    if (evento == NULL) {
        cout << "Evento no encontrado o no esta activo." << endl;
        return;
    }

    string nombre, telefono;
    cout << "Ingrese nombre del invitado: ";
    getline(cin, nombre);
    cout << "Ingrese telefono del invitado: ";
    getline(cin, telefono);

    if (evento->agregarInvitado(nombre, telefono)) {
        cout << "Invitado registrado con exito en el evento." << endl;
    }
}

void finalizarEvento(Evento** eventos, int numEventos) {
    if (numEventos == 0) {
        cout << "No hay eventos registrados." << endl;
        return;
    }

    mostrarEventosActivos(eventos, numEventos);

    int idEvento;
    cout << "Ingrese ID del evento a finalizar: ";
    cin >> idEvento;
    cin.ignore();

    Evento* evento = buscarEventoPorId(eventos, numEventos, idEvento);

    if (evento == NULL) {
        cout << "Evento no encontrado o no esta activo." << endl;
        return;
    }

    evento->finalizarEvento();
    cout << "Evento finalizado con exito. El rank del organizador ha sido incrementado." << endl;
}