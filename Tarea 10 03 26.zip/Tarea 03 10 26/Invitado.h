#pragma once
#include <iostream>
#include <string>
using namespace std;

class Invitado {
private:
    string nombre;
    string telefono;

public:
    Invitado();
    Invitado(string nombre, string telefono);

    string getNombre();
    string getTelefono();

    void mostrarInfo();
};

