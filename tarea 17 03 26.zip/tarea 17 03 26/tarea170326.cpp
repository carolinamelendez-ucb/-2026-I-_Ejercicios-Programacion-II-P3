#include "PlataformaEducativa.h"
#include <iostream>
#include <string>
using namespace std;

int main() {
    PlataformaEducativa plataforma;

    cout << "=== SISTEMA DE GESTION DE CURSOS ===" << endl;
    cout << endl;

    cout << "--- REGISTRO DE INSTRUCTORES ---" << endl;
    plataforma.registrarInstructor("Juan Perez", "123456");
    plataforma.registrarInstructor("Maria Lopez", "789012");
    plataforma.registrarInstructor("Carlos Ruiz", "345678");
    plataforma.registrarInstructor("Ana Gomez", "901234");
    cout << endl;

    plataforma.mostrarInstructoresOrdenadosPorCursos();
    cout << endl;

    cout << "--- REGISTRO DE CURSOS ---" << endl;
    plataforma.registrarCurso("Programacion I", 3);
    plataforma.registrarCurso("Base de Datos", 2);
    plataforma.registrarCurso("Estructura de Datos", 2);
    plataforma.registrarCurso("Redes", 2);
    cout << endl;

    cout << "--- REGISTRO DE ESTUDIANTES ---" << endl;
    plataforma.registrarEstudianteEnCurso(1, "Luis Fernandez", "luis@email.com");
    plataforma.registrarEstudianteEnCurso(1, "Marta Suarez", "marta@email.com");
    plataforma.registrarEstudianteEnCurso(1, "Pedro Ramirez", "pedro@email.com");
    plataforma.registrarEstudianteEnCurso(1, "Sofia Torres", "sofia@email.com"); 

    plataforma.registrarEstudianteEnCurso(2, "Diego Castro", "diego@email.com");
    plataforma.registrarEstudianteEnCurso(2, "Laura Mendoza", "laura@email.com");
    cout << endl;

    cout << "--- FINALIZACIÓN DE CURSOS ---" << endl;
    plataforma.finalizarCurso(1);
    plataforma.finalizarCurso(2);
    cout << endl;

    plataforma.mostrarInstructoresOrdenadosPorCursos();
    cout << endl;

    cout << "--- REGISTRO DE MAS CURSOS ---" << endl;
    plataforma.registrarCurso("Inteligencia Artificial", 2);
    plataforma.registrarCurso("Desarrollo Web", 2);
    cout << endl;

    plataforma.mostrarInstructorMayorCursos();
    cout << endl;

    plataforma.mostrarInstructoresOrdenadosPorCursos();

    return 0;
}