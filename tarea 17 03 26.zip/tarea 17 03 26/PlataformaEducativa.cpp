#include "PlataformaEducativa.h"
#include <iostream>
#include <string>
using namespace std;

PlataformaEducativa::PlataformaEducativa() {
    capacidadInstructores = 2;
    numInstructores = 0;
    instructores = new Instructor[capacidadInstructores];

    capacidadCursos = 2;
    numCursos = 0;
    cursos = new Curso[capacidadCursos];

    siguienteIdCurso = 1;
}

PlataformaEducativa::~PlataformaEducativa() {
    for (int i = 0; i < numCursos; i++) {
        delete[] cursos[i].estudiantes;
    }
    delete[] instructores;
    delete[] cursos;
}

void PlataformaEducativa::redimensionarInstructores() {
    capacidadInstructores *= 2;
    Instructor* nuevoArray = new Instructor[capacidadInstructores];

    for (int i = 0; i < numInstructores; i++) {
        nuevoArray[i] = instructores[i];
    }

    delete[] instructores;
    instructores = nuevoArray;
}

void PlataformaEducativa::redimensionarCursos() {
    capacidadCursos *= 2;
    Curso* nuevoArray = new Curso[capacidadCursos];

    for (int i = 0; i < numCursos; i++) {
        nuevoArray[i] = cursos[i];
    }

    delete[] cursos;
    cursos = nuevoArray;
}

int PlataformaEducativa::buscarInstructorLibreMenosCursos() {
    int indiceInstructor = -1;
    int menorCursos = 999999;

    for (int i = 0; i < numInstructores; i++) {
        if (instructores[i].estado == "libre" && instructores[i].cursosRealizados < menorCursos) {
            menorCursos = instructores[i].cursosRealizados;
            indiceInstructor = i;
        }
    }

    return indiceInstructor;
}

int PlataformaEducativa::buscarCursoPorId(int id) {
    for (int i = 0; i < numCursos; i++) {
        if (cursos[i].id == id) {
            return i;
        }
    }
    return -1;
}

void PlataformaEducativa::registrarInstructor(string nombre, string carnet) {
    if (numInstructores >= capacidadInstructores) {
        redimensionarInstructores();
    }

    instructores[numInstructores].nombre = nombre;
    instructores[numInstructores].carnet = carnet;
    instructores[numInstructores].cursosRealizados = 0;
    instructores[numInstructores].estado = "libre";

    numInstructores++;
    cout << "Instructor " << nombre << " registrado exitosamente." << endl;
}

void PlataformaEducativa::mostrarInstructoresOrdenadosPorCursos() {
    if (numInstructores == 0) {
        cout << "No hay instructores registrados." << endl;
        return;
    }

    Instructor* temp = new Instructor[numInstructores];
    for (int i = 0; i < numInstructores; i++) {
        temp[i] = instructores[i];
    }

    for (int i = 0; i < numInstructores - 1; i++) {
        for (int j = 0; j < numInstructores - i - 1; j++) {
            if (temp[j].cursosRealizados > temp[j + 1].cursosRealizados) {
                Instructor aux = temp[j];
                temp[j] = temp[j + 1];
                temp[j + 1] = aux;
            }
        }
    }

    cout << "\n=== INSTRUCTORES ORDENADOS POR CURSOS REALIZADOS ===" << endl;
    for (int i = 0; i < numInstructores; i++) {
        cout << "Nombre: " << temp[i].nombre
            << " | Carnet: " << temp[i].carnet
            << " | Cursos: " << temp[i].cursosRealizados
            << " | Estado: " << temp[i].estado << endl;
    }

    delete[] temp;
}

void PlataformaEducativa::registrarCurso(string nombre, int maxEstudiantes) {
    int indiceInstructor = buscarInstructorLibreMenosCursos();

    if (indiceInstructor == -1) {
        cout << "No hay instructores libres disponibles. No se puede registrar el curso." << endl;
        return;
    }

    if (numCursos >= capacidadCursos) {
        redimensionarCursos();
    }

    cursos[numCursos].id = siguienteIdCurso;
    cursos[numCursos].nombre = nombre;
    cursos[numCursos].maxEstudiantes = maxEstudiantes;
    cursos[numCursos].estudiantes = new Estudiante[maxEstudiantes];
    cursos[numCursos].numEstudiantesActual = 0;
    cursos[numCursos].instructorAsignado = &instructores[indiceInstructor];

    instructores[indiceInstructor].estado = "ocupado";

    cout << "Curso registrado exitosamente." << endl;
    cout << "ID del curso: " << siguienteIdCurso << endl;
    cout << "Instructor asignado: " << instructores[indiceInstructor].nombre << endl;

    siguienteIdCurso++;
    numCursos++;
}

void PlataformaEducativa::registrarEstudianteEnCurso(int idCurso, string nombreEstudiante, string emailEstudiante) {
    int indiceCurso = buscarCursoPorId(idCurso);

    if (indiceCurso == -1) {
        cout << "Curso con ID " << idCurso << " no encontrado." << endl;
        return;
    }

    Curso& curso = cursos[indiceCurso];

    if (curso.numEstudiantesActual >= curso.maxEstudiantes) {
        cout << "El curso " << curso.nombre << " ha alcanzado su capacidad m�xima." << endl;
        return;
    }

    curso.estudiantes[curso.numEstudiantesActual].nombre = nombreEstudiante;
    curso.estudiantes[curso.numEstudiantesActual].email = emailEstudiante;
    curso.numEstudiantesActual++;

    cout << "Estudiante " << nombreEstudiante << " registrado en el curso " << curso.nombre << endl;
}

void PlataformaEducativa::finalizarCurso(int idCurso) {
    int indiceCurso = buscarCursoPorId(idCurso);

    if (indiceCurso == -1) {
        cout << "Curso con ID " << idCurso << " no encontrado." << endl;
        return;
    }

    Curso& curso = cursos[indiceCurso];

    if (curso.instructorAsignado != nullptr) {
        curso.instructorAsignado->cursosRealizados++;
        curso.instructorAsignado->estado = "libre";

        cout << "Curso " << curso.nombre << " finalizado." << endl;
        cout << "Instructor " << curso.instructorAsignado->nombre
            << " ahora tiene " << curso.instructorAsignado->cursosRealizados
            << " cursos realizados." << endl;
    }

    curso.instructorAsignado = nullptr;
}

void PlataformaEducativa::mostrarInstructorMayorCursos() {
    if (numInstructores == 0) {
        cout << "No hay instructores registrados." << endl;
        return;
    }

    int maxCursos = -1;
    int indiceMayor = -1;

    for (int i = 0; i < numInstructores; i++) {
        if (instructores[i].cursosRealizados > maxCursos) {
            maxCursos = instructores[i].cursosRealizados;
            indiceMayor = i;
        }
    }

    cout << "\n=== INSTRUCTOR CON MAYOR CANTIDAD DE CURSOS REALIZADOS ===" << endl;
    if (indiceMayor != -1) {
        cout << "Nombre: " << instructores[indiceMayor].nombre << endl;
        cout << "Carnet: " << instructores[indiceMayor].carnet << endl;
        cout << "Cursos realizados: " << instructores[indiceMayor].cursosRealizados << endl;
        cout << "Estado: " << instructores[indiceMayor].estado << endl;
    }
}