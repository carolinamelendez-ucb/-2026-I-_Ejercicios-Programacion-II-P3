#pragma once
#include <iostream>
#include <string>
using namespace std;

struct Instructor {
    string nombre;
    string carnet;
    int cursosRealizados;
    string estado;
};

struct Estudiante {
    string nombre;
    string email;
};

struct Curso {
    int id;
    string nombre;
    int maxEstudiantes;
    Estudiante* estudiantes;
    int numEstudiantesActual;
    Instructor* instructorAsignado;
};

class PlataformaEducativa {
private:
    Instructor* instructores;
    int numInstructores;
    int capacidadInstructores;

    Curso* cursos;
    int numCursos;
    int capacidadCursos;

    int siguienteIdCurso;

    void redimensionarInstructores();
    void redimensionarCursos();
    int buscarInstructorLibreMenosCursos();
    int buscarCursoPorId(int id);

public:
    PlataformaEducativa();
    ~PlataformaEducativa();

    void registrarInstructor(string nombre, string carnet);
    void mostrarInstructoresOrdenadosPorCursos();
    void registrarCurso(string nombre, int maxEstudiantes);
    void registrarEstudianteEnCurso(int idCurso, string nombreEstudiante, string emailEstudiante);
    void finalizarCurso(int idCurso);
    void mostrarInstructorMayorCursos();
};
