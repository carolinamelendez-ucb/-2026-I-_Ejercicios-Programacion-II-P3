#pragma once
#include <iostream>
#include <string>
using namespace std;

struct Estudiante {
    string ci;
    string nombre;
    int prestamosActivos;
};

struct Libro {
    string codigo;
    string titulo;
    string estado;
};

struct Prestamo {
    string ciEstudiante;
    string codigoLibro;
    string estado;
};

class Biblioteca {
private:
    Estudiante* estudiantes;
    int numEstudiantes;
    int capacidadEstudiantes;

    Libro* libros;
    int numLibros;
    int capacidadLibros;

    Prestamo* prestamos;
    int numPrestamos;
    int capacidadPrestamos;

    void redimensionarEstudiantes();
    void redimensionarLibros();
    void redimensionarPrestamos();
    int buscarEstudiantePorCI(string ci);
    int buscarLibroPorCodigo(string codigo);
    int buscarPrestamoActivo(string ciEstudiante, string codigoLibro);

public:
    Biblioteca();
    ~Biblioteca();

    void registrarEstudiante(string ci, string nombre);
    void registrarLibro(string codigo, string titulo);
    void prestarLibro(string ciEstudiante, string codigoLibro);
    void devolverLibro(string ciEstudiante, string codigoLibro);
    void mostrarEstudiantesConMaximoPrestamos();
    void mostrarTodosLosPrestamos();
};

