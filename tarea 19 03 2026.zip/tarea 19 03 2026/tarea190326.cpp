#include "Biblioteca.h"
#include <iostream>
#include <string>
using namespace std;

void mostrarMenu() {
    cout << "\n=== SISTEMA DE GESTION DE BIBLIOTECA ===" << endl;
    cout << "1. Registrar estudiante" << endl;
    cout << "2. Registrar libro" << endl;
    cout << "3. Prestar libro" << endl;
    cout << "4. Devolver libro" << endl;
    cout << "5. Mostrar estudiantes con 5 prestamos activos" << endl;
    cout << "6. Mostrar todos los prestamos" << endl;
    cout << "7. Salir" << endl;
    cout << "Seleccione una opcion: ";
}

int main() {
    Biblioteca biblioteca;
    int opcion;
    string ci, nombre, codigo, titulo;

    cout << "=== CARGANDO DATOS DE EJEMPLO ===" << endl;
    biblioteca.registrarEstudiante("123456", "Juan Perez");
    biblioteca.registrarEstudiante("789012", "Maria Lopez");
    biblioteca.registrarEstudiante("345678", "Carlos Ruiz");
    biblioteca.registrarEstudiante("901234", "Ana Gomez");

    biblioteca.registrarLibro("L001", "Cien años de soledad");
    biblioteca.registrarLibro("L002", "El principito");
    biblioteca.registrarLibro("L003", "Don Quijote de la Mancha");
    biblioteca.registrarLibro("L004", "La metamorfosis");
    biblioteca.registrarLibro("L005", "1984");
    biblioteca.registrarLibro("L006", "El amor en los tiempos del colera");

    do {
        mostrarMenu();
        cin >> opcion;
        cin.ignore();

        switch (opcion) {
        case 1:
            cout << "Ingrese CI del estudiante: ";
            getline(cin, ci);
            cout << "Ingrese nombre del estudiante: ";
            getline(cin, nombre);
            biblioteca.registrarEstudiante(ci, nombre);
            break;

        case 2:
            cout << "Ingrese codigo del libro: ";
            getline(cin, codigo);
            cout << "Ingrese titulo del libro: ";
            getline(cin, titulo);
            biblioteca.registrarLibro(codigo, titulo);
            break;

        case 3:
            cout << "Ingrese CI del estudiante: ";
            getline(cin, ci);
            cout << "Ingrese codigo del libro: ";
            getline(cin, codigo);
            biblioteca.prestarLibro(ci, codigo);
            break;

        case 4:
            cout << "Ingrese CI del estudiante: ";
            getline(cin, ci);
            cout << "Ingrese codigo del libro: ";
            getline(cin, codigo);
            biblioteca.devolverLibro(ci, codigo);
            break;

        case 5:
            biblioteca.mostrarEstudiantesConMaximoPrestamos();
            break;

        case 6:
            biblioteca.mostrarTodosLosPrestamos();
            break;

        case 7:
            cout << "Saliendo del sistema..." << endl;
            break;

        default:
            cout << "Opcion no valida. Intente de nuevo." << endl;
        }

    } while (opcion != 7);

    cout << "\n=== DEMOSTRACION ADICIONAL ===" << endl;
    cout << "Realizando prestamos para demostrar limite de 5..." << endl;

    biblioteca.prestarLibro("123456", "L001");
    biblioteca.prestarLibro("123456", "L002");
    biblioteca.prestarLibro("123456", "L003");
    biblioteca.prestarLibro("123456", "L004");
    biblioteca.prestarLibro("123456", "L005");
    biblioteca.prestarLibro("123456", "L006");

    biblioteca.mostrarEstudiantesConMaximoPrestamos();
    biblioteca.mostrarTodosLosPrestamos();

    cout << "\nDevolviendo un libro..." << endl;
    biblioteca.devolverLibro("123456", "L001");
    biblioteca.mostrarEstudiantesConMaximoPrestamos();
    biblioteca.mostrarTodosLosPrestamos();

    return 0;
}