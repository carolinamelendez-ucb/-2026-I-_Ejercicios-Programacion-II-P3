#include "Biblioteca.h"
#include <iostream>
#include <string>
using namespace std;

Biblioteca::Biblioteca() {
    capacidadEstudiantes = 2;
    numEstudiantes = 0;
    estudiantes = new Estudiante[capacidadEstudiantes];

    capacidadLibros = 2;
    numLibros = 0;
    libros = new Libro[capacidadLibros];

    capacidadPrestamos = 2;
    numPrestamos = 0;
    prestamos = new Prestamo[capacidadPrestamos];
}

Biblioteca::~Biblioteca() {
    delete[] estudiantes;
    delete[] libros;
    delete[] prestamos;
}

void Biblioteca::redimensionarEstudiantes() {
    capacidadEstudiantes *= 2;
    Estudiante* nuevoArray = new Estudiante[capacidadEstudiantes];

    for (int i = 0; i < numEstudiantes; i++) {
        nuevoArray[i] = estudiantes[i];
    }

    delete[] estudiantes;
    estudiantes = nuevoArray;
}

void Biblioteca::redimensionarLibros() {
    capacidadLibros *= 2;
    Libro* nuevoArray = new Libro[capacidadLibros];

    for (int i = 0; i < numLibros; i++) {
        nuevoArray[i] = libros[i];
    }

    delete[] libros;
    libros = nuevoArray;
}

void Biblioteca::redimensionarPrestamos() {
    capacidadPrestamos *= 2;
    Prestamo* nuevoArray = new Prestamo[capacidadPrestamos];

    for (int i = 0; i < numPrestamos; i++) {
        nuevoArray[i] = prestamos[i];
    }

    delete[] prestamos;
    prestamos = nuevoArray;
}

int Biblioteca::buscarEstudiantePorCI(string ci) {
    for (int i = 0; i < numEstudiantes; i++) {
        if (estudiantes[i].ci == ci) {
            return i;
        }
    }
    return -1;
}

int Biblioteca::buscarLibroPorCodigo(string codigo) {
    for (int i = 0; i < numLibros; i++) {
        if (libros[i].codigo == codigo) {
            return i;
        }
    }
    return -1;
}

int Biblioteca::buscarPrestamoActivo(string ciEstudiante, string codigoLibro) {
    for (int i = 0; i < numPrestamos; i++) {
        if (prestamos[i].ciEstudiante == ciEstudiante &&
            prestamos[i].codigoLibro == codigoLibro &&
            prestamos[i].estado == "activo") {
            return i;
        }
    }
    return -1;
}

void Biblioteca::registrarEstudiante(string ci, string nombre) {
    if (buscarEstudiantePorCI(ci) != -1) {
        cout << "Error: Ya existe un estudiante con CI " << ci << endl;
        return;
    }

    if (numEstudiantes >= capacidadEstudiantes) {
        redimensionarEstudiantes();
    }

    estudiantes[numEstudiantes].ci = ci;
    estudiantes[numEstudiantes].nombre = nombre;
    estudiantes[numEstudiantes].prestamosActivos = 0;

    numEstudiantes++;
    cout << "Estudiante " << nombre << " registrado exitosamente." << endl;
}

void Biblioteca::registrarLibro(string codigo, string titulo) {
    if (buscarLibroPorCodigo(codigo) != -1) {
        cout << "Error: Ya existe un libro con codigo " << codigo << endl;
        return;
    }

    if (numLibros >= capacidadLibros) {
        redimensionarLibros();
    }

    libros[numLibros].codigo = codigo;
    libros[numLibros].titulo = titulo;
    libros[numLibros].estado = "disponible";

    numLibros++;
    cout << "Libro \"" << titulo << "\" registrado exitosamente." << endl;
}

void Biblioteca::prestarLibro(string ciEstudiante, string codigoLibro) {
    int indiceEstudiante = buscarEstudiantePorCI(ciEstudiante);
    if (indiceEstudiante == -1) {
        cout << "Error: Estudiante con CI " << ciEstudiante << " no encontrado." << endl;
        return;
    }

    int indiceLibro = buscarLibroPorCodigo(codigoLibro);
    if (indiceLibro == -1) {
        cout << "Error: Libro con codigo " << codigoLibro << " no encontrado." << endl;
        return;
    }

    if (libros[indiceLibro].estado != "disponible") {
        cout << "Error: El libro \"" << libros[indiceLibro].titulo << "\" no esta disponible." << endl;
        return;
    }

    if (estudiantes[indiceEstudiante].prestamosActivos >= 5) {
        cout << "Error: El estudiante " << estudiantes[indiceEstudiante].nombre
            << " ya tiene 5 prestamos activos. No puede tomar mas libros." << endl;
        return;
    }

    if (buscarPrestamoActivo(ciEstudiante, codigoLibro) != -1) {
        cout << "Error: El estudiante ya tiene prestado este libro." << endl;
        return;
    }

    if (numPrestamos >= capacidadPrestamos) {
        redimensionarPrestamos();
    }

    prestamos[numPrestamos].ciEstudiante = ciEstudiante;
    prestamos[numPrestamos].codigoLibro = codigoLibro;
    prestamos[numPrestamos].estado = "activo";

    libros[indiceLibro].estado = "no disponible";
    estudiantes[indiceEstudiante].prestamosActivos++;

    numPrestamos++;
    cout << "Prestamo realizado exitosamente." << endl;
    cout << "Estudiante: " << estudiantes[indiceEstudiante].nombre << endl;
    cout << "Libro: " << libros[indiceLibro].titulo << endl;
    cout << "Prestamos activos del estudiante: " << estudiantes[indiceEstudiante].prestamosActivos << endl;
}

void Biblioteca::devolverLibro(string ciEstudiante, string codigoLibro) {
    int indiceEstudiante = buscarEstudiantePorCI(ciEstudiante);
    if (indiceEstudiante == -1) {
        cout << "Error: Estudiante con CI " << ciEstudiante << " no encontrado." << endl;
        return;
    }

    int indiceLibro = buscarLibroPorCodigo(codigoLibro);
    if (indiceLibro == -1) {
        cout << "Error: Libro con codigo " << codigoLibro << " no encontrado." << endl;
        return;
    }

    int indicePrestamo = buscarPrestamoActivo(ciEstudiante, codigoLibro);
    if (indicePrestamo == -1) {
        cout << "Error: No se encontro un prestamo activo para este estudiante y libro." << endl;
        return;
    }

    prestamos[indicePrestamo].estado = "inactivo";
    libros[indiceLibro].estado = "disponible";
    estudiantes[indiceEstudiante].prestamosActivos--;

    cout << "Libro devuelto exitosamente." << endl;
    cout << "Estudiante: " << estudiantes[indiceEstudiante].nombre << endl;
    cout << "Libro: " << libros[indiceLibro].titulo << endl;
    cout << "Prestamos activos restantes: " << estudiantes[indiceEstudiante].prestamosActivos << endl;
}

void Biblioteca::mostrarEstudiantesConMaximoPrestamos() {
    cout << "\n=== ESTUDIANTES CON 5 PRESTAMOS ACTIVOS ===" << endl;

    bool encontrado = false;

    for (int i = 0; i < numEstudiantes; i++) {
        if (estudiantes[i].prestamosActivos == 5) {
            cout << "CI: " << estudiantes[i].ci << endl;
            cout << "Nombre: " << estudiantes[i].nombre << endl;
            cout << "Prestamos activos: " << estudiantes[i].prestamosActivos << endl;
            cout << "------------------------" << endl;
            encontrado = true;
        }
    }

    if (!encontrado) {
        cout << "No hay estudiantes con 5 prestamos activos." << endl;
    }
}

void Biblioteca::mostrarTodosLosPrestamos() {
    cout << "\n=== INFORMACION DE TODOS LOS PRESTAMOS ===" << endl;

    if (numPrestamos == 0) {
        cout << "No hay prestamos registrados." << endl;
        return;
    }

    for (int i = 0; i < numPrestamos; i++) {
        int indiceEstudiante = buscarEstudiantePorCI(prestamos[i].ciEstudiante);
        string nombreEstudiante = (indiceEstudiante != -1) ? estudiantes[indiceEstudiante].nombre : "Desconocido";

        int indiceLibro = buscarLibroPorCodigo(prestamos[i].codigoLibro);
        string tituloLibro = (indiceLibro != -1) ? libros[indiceLibro].titulo : "Desconocido";

        cout << "Prestamo #" << (i + 1) << endl;
        cout << "  Estudiante: " << nombreEstudiante << " (CI: " << prestamos[i].ciEstudiante << ")" << endl;
        cout << "  Libro: " << tituloLibro << " (Codigo: " << prestamos[i].codigoLibro << ")" << endl;
        cout << "  Estado: " << prestamos[i].estado << endl;
        cout << "------------------------" << endl;
    }
}