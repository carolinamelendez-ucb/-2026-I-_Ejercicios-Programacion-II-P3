#pragma once
#include <iostream>
#include <string>
#include "Pelicula.h"
#include "Sala.h"
using namespace std;

class Funcion {
private:
    int idFuncion;
    string horario;
    Pelicula pelicula;
    Sala sala;
    double precioBase;
    int asientosVendidos;
    double gananciaTotal;
    char asientos[50][50];

public:
    Funcion();
    Funcion(int id, string hora, Pelicula peli, Sala sal, double precio);

    int getIdFuncion();
    string getHorario();
    Pelicula getPelicula();
    Sala getSala();
    double getPrecioBase();
    int getAsientosVendidos();
    double getGananciaTotal();

    void setIdFuncion(int id);
    void setHorario(string hora);
    void setPelicula(Pelicula peli);
    void setSala(Sala sal);
    void setPrecioBase(double precio);

    void inicializarAsientos();
    void mostrarAsientos();
    bool venderAsiento(int fila, int asiento);
    void mostrarInformacion();
    void calcularGanancia();
};