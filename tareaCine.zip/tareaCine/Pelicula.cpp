#include "Pelicula.h"

Pelicula::Pelicula() {
    titulo = "";
    genero = "";
    duracion = 0;
}

Pelicula::Pelicula(string tit, string gen, int dur) {
    titulo = tit;
    genero = gen;
    duracion = dur;
}

string Pelicula::getTitulo() {
    return titulo;
}

string Pelicula::getGenero() {
    return genero;
}

int Pelicula::getDuracion() {
    return duracion;
}

void Pelicula::setTitulo(string tit) {
    titulo = tit;
}

void Pelicula::setGenero(string gen) {
    genero = gen;
}

void Pelicula::setDuracion(int dur) {
    duracion = dur;
}

void Pelicula::mostrarInformacion() {
    cout << "Titulo: " << titulo << endl;
    cout << "Genero: " << genero << endl;
    cout << "Duracion: " << duracion << " minutos" << endl;
}