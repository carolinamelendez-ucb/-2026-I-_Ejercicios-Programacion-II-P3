#include "Sala.h"

Sala::Sala() {
    numeroSala = 0;
    filas = 0;
    asientosPorFila = 0;
    totalAsientos = 0;
}

Sala::Sala(int num, int f, int asFila) {
    numeroSala = num;
    filas = f;
    asientosPorFila = asFila;
    totalAsientos = filas * asientosPorFila;
}

int Sala::getNumeroSala() {
    return numeroSala;
}

int Sala::getFilas() {
    return filas;
}

int Sala::getAsientosPorFila() {
    return asientosPorFila;
}

int Sala::getTotalAsientos() {
    return totalAsientos;
}

void Sala::setNumeroSala(int num) {
    numeroSala = num;
}

void Sala::setFilas(int f) {
    filas = f;
}

void Sala::setAsientosPorFila(int asFila) {
    asientosPorFila = asFila;
    totalAsientos = filas * asientosPorFila;
}

void Sala::mostrarInformacion() {
    cout << "Numero de Sala: " << numeroSala << endl;
    cout << "Filas: " << filas << endl;
    cout << "Asientos por fila: " << asientosPorFila << endl;
    cout << "Total de asientos: " << totalAsientos << endl;
}