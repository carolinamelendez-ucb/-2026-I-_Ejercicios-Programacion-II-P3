#pragma once
#include <iostream>
#include <string>
#include "Cliente.h"
#include "Sala.h"
#include "Pelicula.h"
#include "Funcion.h"
using namespace std;

class SistemaCine {
private:
    Cliente clientes[100];
    Sala salas[50];
    Pelicula peliculas[50];
    Funcion funciones[50];

    int totalClientes;
    int totalSalas;
    int totalPeliculas;
    int totalFunciones;

public:
    SistemaCine();

    void registrarCliente();
    void mostrarClientes();

    void registrarSala();
    void mostrarSalas();

    void registrarPelicula();
    void mostrarPeliculas();

    void registrarFuncion();
    void mostrarFunciones();

    void venderBoleto();

    void reporteGananciasPorFuncion();
    void reporteGananciasPorPelicula();

    void menu();
};