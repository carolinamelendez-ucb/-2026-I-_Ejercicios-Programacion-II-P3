#pragma once
#include <iostream>
#include <string>
using namespace std;

class Cliente {
private:
    string nombre;
    string identificacion;
    int edad;

public:
    Cliente();
    Cliente(string nom, string id, int ed);

    string getNombre();
    string getIdentificacion();
    int getEdad();

    void setNombre(string nom);
    void setIdentificacion(string id);
    void setEdad(int ed);

    void mostrarInformacion();
};

