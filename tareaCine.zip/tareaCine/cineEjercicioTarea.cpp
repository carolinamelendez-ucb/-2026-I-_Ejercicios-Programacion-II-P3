#include "SistemaCine.h"

int main() {
    SistemaCine sistema;
    sistema.menu();

    return 0;
}