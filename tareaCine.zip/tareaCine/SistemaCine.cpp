#include "SistemaCine.h"

SistemaCine::SistemaCine() {
    totalClientes = 0;
    totalSalas = 0;
    totalPeliculas = 0;
    totalFunciones = 0;
}

void SistemaCine::registrarCliente() {
    if (totalClientes < 100) {
        string nombre, id;
        int edad;

        cout << "Registro de Cliente" << endl;
        cout << "Nombre: ";
        cin.ignore();
        getline(cin, nombre);
        cout << "Identificacion: ";
        getline(cin, id);
        cout << "Edad: ";
        cin >> edad;

        clientes[totalClientes] = Cliente(nombre, id, edad);
        totalClientes++;
        cout << "Cliente registrado exitosamente!" << endl;
    }
    else {
        cout << "No se pueden registrar mas clientes (limite alcanzado)" << endl;
    }
}

void SistemaCine::mostrarClientes() {
    if (totalClientes == 0) {
        cout << "No hay clientes registrados" << endl;
        return;
    }

    cout << "\n=== Lista de clientes ===" << endl;
    for (int i = 0; i < totalClientes; i++) {
        cout << "\nCliente " << i + 1 << ":" << endl;
        clientes[i].mostrarInformacion();
    }
}

void SistemaCine::registrarSala() {
    if (totalSalas < 50) {
        int num, filas, asientos;

        cout << "Registro de Sala" << endl;
        cout << "Numero de sala: ";
        cin >> num;
        cout << "Numero de filas: ";
        cin >> filas;
        cout << "Asientos por fila: ";
        cin >> asientos;

        salas[totalSalas] = Sala(num, filas, asientos);
        totalSalas++;
        cout << "Sala registrada exitosamente!" << endl;
    }
    else {
        cout << "No se pueden registrar mas salas (limite alcanzado)" << endl;
    }
}

void SistemaCine::mostrarSalas() {
    if (totalSalas == 0) {
        cout << "No hay salas registradas" << endl;
        return;
    }

    cout << "\n=== LISTA DE SALAS ===" << endl;
    for (int i = 0; i < totalSalas; i++) {
        cout << "\nSala " << i + 1 << ":" << endl;
        salas[i].mostrarInformacion();
    }
}

void SistemaCine::registrarPelicula() {
    if (totalPeliculas < 50) {
        string titulo, genero;
        int duracion;

        cout << "Registro de Pelicula" << endl;
        cout << "Titulo: ";
        cin.ignore();
        getline(cin, titulo);
        cout << "Genero: ";
        getline(cin, genero);
        cout << "Duracion (minutos): ";
        cin >> duracion;

        peliculas[totalPeliculas] = Pelicula(titulo, genero, duracion);
        totalPeliculas++;
        cout << "Pelicula registrada exitosamente!" << endl;
    }
    else {
        cout << "No se pueden registrar mas peliculas (limite alcanzado)" << endl;
    }
}

void SistemaCine::mostrarPeliculas() {
    if (totalPeliculas == 0) {
        cout << "No hay peliculas registradas" << endl;
        return;
    }

    cout << "\n=== LISTA DE PELICULAS ===" << endl;
    for (int i = 0; i < totalPeliculas; i++) {
        cout << "\nPelicula " << i + 1 << ":" << endl;
        peliculas[i].mostrarInformacion();
    }
}

void SistemaCine::registrarFuncion() {
    if (totalFunciones < 50) {
        if (totalPeliculas == 0 || totalSalas == 0) {
            cout << "Debe haber al menos una pelicula y una sala registradas" << endl;
            return;
        }

        int id, idPelicula, idSala;
        string horario;
        double precio;

        cout << "Registro de Funcion" << endl;
        cout << "ID Funcion: ";
        cin >> id;

        cout << "\nPeliculas disponibles:" << endl;
        for (int i = 0; i < totalPeliculas; i++) {
            cout << i + 1 << ". " << peliculas[i].getTitulo() << endl;
        }
        cout << "Seleccione pelicula: ";
        cin >> idPelicula;

        cout << "\nSalas disponibles:" << endl;
        for (int i = 0; i < totalSalas; i++) {
            cout << i + 1 << ". Sala " << salas[i].getNumeroSala() << endl;
        }
        cout << "Seleccione sala: ";
        cin >> idSala;

        cout << "Horario: ";
        cin.ignore();
        getline(cin, horario);
        cout << "Precio base: $";
        cin >> precio;

        funciones[totalFunciones] = Funcion(id, horario, peliculas[idPelicula - 1], salas[idSala - 1], precio);
        totalFunciones++;
        cout << "Funcion registrada exitosamente!" << endl;
    }
    else {
        cout << "No se pueden registrar mas funciones (limite alcanzado)" << endl;
    }
}

void SistemaCine::mostrarFunciones() {
    if (totalFunciones == 0) {
        cout << "No hay funciones registradas" << endl;
        return;
    }

    cout << "\n=== Lista de funciones ===" << endl;
    for (int i = 0; i < totalFunciones; i++) {
        cout << "\nFuncion " << i + 1 << ":" << endl;
        funciones[i].mostrarInformacion();
    }
}

void SistemaCine::venderBoleto() {
    if (totalFunciones == 0) {
        cout << "No hay funciones disponibles" << endl;
        return;
    }

    int idFuncion;
    cout << "\nFunciones disponibles:" << endl;
    for (int i = 0; i < totalFunciones; i++) {
        cout << i + 1 << ". ID: " << funciones[i].getIdFuncion()
            << " - " << funciones[i].getPelicula().getTitulo()
            << " - " << funciones[i].getHorario() << endl;
    }

    cout << "Seleccione funcion: ";
    cin >> idFuncion;

    int indice = idFuncion - 1;
    if (indice >= 0 && indice < totalFunciones) {
        char filaChar;
        int numAsiento;

        cout << "\nAsientos disponibles:" << endl;
        funciones[indice].mostrarAsientos();

        cout << "\nSeleccione fila (A, B, C...): ";
        cin >> filaChar;
        cout << "Seleccione numero de asiento: ";
        cin >> numAsiento;

        int fila = filaChar - 'A';
        int asiento = numAsiento - 1;

        if (funciones[indice].venderAsiento(fila, asiento)) {
            cout << "Boleto vendido exitosamente!" << endl;
        }
        else {
            cout << "No se pudo vender el boleto (asiento no disponible o invalido)" << endl;
        }
    }
    else {
        cout << "Funcion no valida" << endl;
    }
}

void SistemaCine::reporteGananciasPorFuncion() {
    if (totalFunciones == 0) {
        cout << "No hay funciones registradas" << endl;
        return;
    }

    cout << "\n=== Ganancias por funcion ===" << endl;
    for (int i = 0; i < totalFunciones; i++) {
        cout << "\nFuncion " << i + 1 << ":" << endl;
        cout << "Pelicula: " << funciones[i].getPelicula().getTitulo() << endl;
        cout << "Horario: " << funciones[i].getHorario() << endl;
        cout << "Asientos vendidos: " << funciones[i].getAsientosVendidos() << endl;
        cout << "Ganancia: $" << funciones[i].getGananciaTotal() << endl;
    }
}

void SistemaCine::reporteGananciasPorPelicula() {
    if (totalFunciones == 0 || totalPeliculas == 0) {
        cout << "No hay funciones o peliculas registradas" << endl;
        return;
    }

    cout << "\n=== Ganancias por pelicula ===" << endl;
    for (int i = 0; i < totalPeliculas; i++) {
        double gananciaTotal = 0;
        int funcionesPelicula = 0;

        for (int j = 0; j < totalFunciones; j++) {
            if (funciones[j].getPelicula().getTitulo() == peliculas[i].getTitulo()) {
                gananciaTotal += funciones[j].getGananciaTotal();
                funcionesPelicula++;
            }
        }

        if (funcionesPelicula > 0) {
            cout << "\nPelicula: " << peliculas[i].getTitulo() << endl;
            cout << "Funciones programadas: " << funcionesPelicula << endl;
            cout << "Ganancia total: $" << gananciaTotal << endl;
        }
    }
}

void SistemaCine::menu() {
    int opcion;

    do {
        cout << "\n=== Sistema de cine ===" << endl;
        cout << "1. Registrar y mostrar clientes" << endl;
        cout << "2. Registrar y mostrar salas" << endl;
        cout << "3. Registrar y mostrar peliculas" << endl;
        cout << "4. Registrar y mostrar funciones" << endl;
        cout << "5. Vender boletos para una funcion" << endl;
        cout << "6. Mostrar reporte de ganancias por funcion" << endl;
        cout << "7. Mostrar reporte de ganancias por pelicula" << endl;
        cout << "8. Salir" << endl;
        cout << "Opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1: {
            int subopcion;
            cout << "\n1. Registrar cliente" << endl;
            cout << "2. Mostrar clientes" << endl;
            cout << "Opcion: ";
            cin >> subopcion;

            if (subopcion == 1) {
                registrarCliente();
            }
            else if (subopcion == 2) {
                mostrarClientes();
            }
            else {
                cout << "Opcion no valida" << endl;
            }
            break;
        }
        case 2: {
            int subopcion;
            cout << "\n1. Registrar sala" << endl;
            cout << "2. Mostrar salas" << endl;
            cout << "Opcion: ";
            cin >> subopcion;

            if (subopcion == 1) {
                registrarSala();
            }
            else if (subopcion == 2) {
                mostrarSalas();
            }
            else {
                cout << "Opcion no valida" << endl;
            }
            break;
        }
        case 3: {
            int subopcion;
            cout << "\n1. Registrar pelicula" << endl;
            cout << "2. Mostrar peliculas" << endl;
            cout << "Opcion: ";
            cin >> subopcion;

            if (subopcion == 1) {
                registrarPelicula();
            }
            else if (subopcion == 2) {
                mostrarPeliculas();
            }
            else {
                cout << "Opcion no valida" << endl;
            }
            break;
        }
        case 4: {
            int subopcion;
            cout << "\n1. Registrar funcion" << endl;
            cout << "2. Mostrar funciones" << endl;
            cout << "Opcion: ";
            cin >> subopcion;

            if (subopcion == 1) {
                registrarFuncion();
            }
            else if (subopcion == 2) {
                mostrarFunciones();
            }
            else {
                cout << "Opcion no valida" << endl;
            }
            break;
        }
        case 5:
            venderBoleto();
            break;
        case 6:
            reporteGananciasPorFuncion();
            break;
        case 7:
            reporteGananciasPorPelicula();
            break;
        case 8:
            cout << "Saliendo del sistema..." << endl;
            break;
        default:
            cout << "Opcion no valida" << endl;
        }
    } while (opcion != 8);
}