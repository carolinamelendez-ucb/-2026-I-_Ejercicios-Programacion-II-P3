#pragma once
#include <iostream>
#include <string>
using namespace std;

class Sala {
private:
    int numeroSala;
    int filas;
    int asientosPorFila;
    int totalAsientos;

public:
    Sala();
    Sala(int num, int f, int asFila);

    int getNumeroSala();
    int getFilas();
    int getAsientosPorFila();
    int getTotalAsientos();

    void setNumeroSala(int num);
    void setFilas(int f);
    void setAsientosPorFila(int asFila);

    void mostrarInformacion();
};