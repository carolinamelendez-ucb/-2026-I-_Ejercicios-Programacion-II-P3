#include "Cliente.h"

Cliente::Cliente() {
    nombre = "";
    identificacion = "";
    edad = 0;
}

Cliente::Cliente(string nom, string id, int ed) {
    nombre = nom;
    identificacion = id;
    edad = ed;
}

string Cliente::getNombre() {
    return nombre;
}

string Cliente::getIdentificacion() {
    return identificacion;
}

int Cliente::getEdad() {
    return edad;
}

void Cliente::setNombre(string nom) {
    nombre = nom;
}

void Cliente::setIdentificacion(string id) {
    identificacion = id;
}

void Cliente::setEdad(int ed) {
    edad = ed;
}

void Cliente::mostrarInformacion() {
    cout << "Nombre: " << nombre << endl;
    cout << "Identificacion: " << identificacion << endl;
    cout << "Edad: " << edad << endl;
}