#include "Funcion.h"

Funcion::Funcion() {
    idFuncion = 0;
    horario = "";
    precioBase = 0;
    asientosVendidos = 0;
    gananciaTotal = 0;
}

Funcion::Funcion(int id, string hora, Pelicula peli, Sala sal, double precio) {
    idFuncion = id;
    horario = hora;
    pelicula = peli;
    sala = sal;
    precioBase = precio;
    asientosVendidos = 0;
    gananciaTotal = 0;
    inicializarAsientos();
}

int Funcion::getIdFuncion() {
    return idFuncion;
}

string Funcion::getHorario() {
    return horario;
}

Pelicula Funcion::getPelicula() {
    return pelicula;
}

Sala Funcion::getSala() {
    return sala;
}

double Funcion::getPrecioBase() {
    return precioBase;
}

int Funcion::getAsientosVendidos() {
    return asientosVendidos;
}

double Funcion::getGananciaTotal() {
    return gananciaTotal;
}

void Funcion::setIdFuncion(int id) {
    idFuncion = id;
}

void Funcion::setHorario(string hora) {
    horario = hora;
}

void Funcion::setPelicula(Pelicula peli) {
    pelicula = peli;
}

void Funcion::setSala(Sala sal) {
    sala = sal;
}

void Funcion::setPrecioBase(double precio) {
    precioBase = precio;
}

void Funcion::inicializarAsientos() {
    int filas = sala.getFilas();
    int asientosPorFila = sala.getAsientosPorFila();

    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < asientosPorFila; j++) {
            asientos[i][j] = 'O';
        }
    }
}

void Funcion::mostrarAsientos() {
    int filas = sala.getFilas();
    int asientosPorFila = sala.getAsientosPorFila();

    cout << "   ";
    for (int j = 0; j < asientosPorFila; j++) {
        if (j < 9) {
            cout << " " << j + 1 << " ";
        }
        else {
            cout << j + 1 << " ";
        }
    }
    cout << endl;

    for (int i = 0; i < filas; i++) {
        cout << char('A' + i) << "  ";
        for (int j = 0; j < asientosPorFila; j++) {
            cout << " " << asientos[i][j] << " ";
        }
        cout << endl;
    }
    cout << "O: Disponible   X: Vendido" << endl;
}

bool Funcion::venderAsiento(int fila, int asiento) {
    if (fila < 0 || fila >= sala.getFilas() || asiento < 0 || asiento >= sala.getAsientosPorFila()) {
        return false;
    }

    if (asientos[fila][asiento] == 'O') {
        asientos[fila][asiento] = 'X';
        asientosVendidos++;
        gananciaTotal += precioBase;
        return true;
    }

    return false;
}

void Funcion::mostrarInformacion() {
    cout << "ID Funcion: " << idFuncion << endl;
    cout << "Horario: " << horario << endl;
    cout << "Pelicula: " << pelicula.getTitulo() << endl;
    cout << "Sala: " << sala.getNumeroSala() << endl;
    cout << "Precio Base: $" << precioBase << endl;
    cout << "Asientos Vendidos: " << asientosVendidos << endl;
    cout << "Ganancia Total: $" << gananciaTotal << endl;
}

void Funcion::calcularGanancia() {
    gananciaTotal = asientosVendidos * precioBase;
}