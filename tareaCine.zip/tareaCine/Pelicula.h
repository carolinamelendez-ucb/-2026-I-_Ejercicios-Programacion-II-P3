#pragma once
#include <iostream>
#include <string>
using namespace std;

class Pelicula {
private:
    string titulo;
    string genero;
    int duracion;

public:
    Pelicula();
    Pelicula(string tit, string gen, int dur);

    string getTitulo();
    string getGenero();
    int getDuracion();

    void setTitulo(string tit);
    void setGenero(string gen);
    void setDuracion(int dur);

    void mostrarInformacion();
};
